# A2: Criminal Justice
Based on the [Criminal Justice](https://responsibleproblemsolving.github.io/#crimjustice) assignment from [Responsible Problem Solving](https://responsibleproblemsolving.github.io/). Original version written for CS 106 - Introduction to Data Structures at Haverford College.

Understanding the Data
----------------------

When designing any data structure, we first need to understand the details of the data that we will store and what types of queries we may want to make about that data. For this assignment, the data we’ll be working with comes from a ProPublica story about a risk assessment tool called
COMPAS.

To understand the data and the larger context, look at these sources in
order:

1.  ProPublica’s [introductory video](https://youtu.be/17eDz5HA_qI).

2.  Article: [Machine Bias](https://www.propublica.org/article/machine-bias-risk-assessments-in-criminal-sentencing) by ProPublica.

3.  Handout: [Understanding Propublica.pdf](https://responsibleproblemsolving.github.io/propublica/understanding_Propublica.pdf).

4.  Look at the (cleaned) data in `compas-scores.csv`.

Feel free to discuss the content with peers and/or instructors.

Creating a Class Representing a Single Row
------------------------------------------

### Create a class

A single row in the CSV represents one `Defendant`. Create a class inside `Defendant.java` that holds information about a single row. Using javadoc style, write a comment to describe the class - what it represents, what contents it holds, etc.

### Fields and methods
Add necessary fields to represent the information about what the class represents based on the CSV - think about its columns! Think carefully about what the most appropriate data type of these fields should be.

After you have created the fields, add any necessary getter and setter methods to the class. Be sure to include appropriate Javadoc comments!

### Constructor

We now need to make the class accept data from outside to initialize the
fields you created in the previous section. Make a constructor that takes in
multiple variables (e.g. `String sex`, `String race`, `...`) and
initializes the fields of your class.

### Test your class

Testing is an important part of developing data structures. In the `Main` class, fill in the `testConstructor()` method that makes an instance of the class and tests your getter and setter methods.

Call your `testConstructor()` method in your `main` method of your
`Main` class to test your work. 
You can also test your work using `System.out.println` to print
variables, but if you do so please declutter the console output by
commenting out these calls once you’re sure it works.

Continue to test your work in the following section similar to how you
did here.

Getting ready to Replicate the Analysis
---------------------------------------

The goal of this assignment is to build the necessary data structures that will enable you to replicate ProPublica’s analysis
shown in the table *Prediction Fails Differently for Black Defendants* (replicated below).


|                                           | WHITE | AFRICAN AMERICAN |
|-------------------------------------------|------:|-----------------:|
| Labeled Higher Risk, But Didn’t Re-Offend | 23.5% |            44.9% |
| Labeled Lower Risk, Yet Did Re-Offend     | 47.7% |            28.0% |

Overall, Northpointe’s assessment tool correctly predicts recidivism 61 percent of the time. But blacks are almost twice as likely as whites to be labeled a higher risk but not actually re-offend. It makes the opposite mistake among whites: They are much more likely than blacks to be labeled lower risk but go on to commit other crimes. (Source: ProPublica analysis of data from Broward County, Fla.)

In order to do this, we need to determine if the person represented by
the row fits the description in the table. For example, to see if
someone is part of the 25.3% in the table, we need to check

1.  if the person is white (or Caucasian)

2.  if the person did not re-offend (i.e., was not labeled as being
    rearrested within 2 years)

3.  if the person was labelled *high risk*

More generally, we need to check the person’s race (white or Black), whether they re-offended, and whether they were labelled *low risk* or *high risk* of recidivism. Make these methods that return `true` or `false` depending on whether a person fits this criteria: `isWhite()`, `isBlack()`, `hasReoffended()`, `isLowRisk()`, and `isHighRisk()`.

Make sure you follow appropriate coding practices, update and maintain
appropriate comments about the class and the methods, and test your
work. Fill in the testing method `testBools()` inside `Main.java` to test your boolean methods.

Data Validation
===============

To help us read the data from the CSV into our data structure, we need to make some modifications. Specifically, we need to
make a new constructor and put safeguards in place about what can be passed into the constructor.

New Constructor
---------------

Later on in the assignment, we will read each row of the CSV as `String` arrays. For this to work, we'll need to write a new constructor that can handle this kind of input.

Do not get rid of the original constructor. In Java, we can *overload* methods - meaning the methods can have the same name as long as their parameters are different. Java compiler will **automatically** look for the method that fits the one you’re calling.

Create a second constructor for the class that takes in a `String` array and initializes the fields. The indices of the array will correspond to the column of the row.

To test your work, please fill out the method called `testStringArrConstructor()` in `Main.java  `.

Safe-guarding the constructor
-----------------------------

We should put some safeguards in place to make sure that we don’t have any data errors when we do the imports from the CSV.

### What are the valid values?

Determine what the valid options are for each field in your class - you’ll likely want to look at `compas-scores.csv` again. Use Javadoc style to document these preconditions.

### Are the values valid?

Within the constructor, perform a check before initializing the fields to ensure the fields only hold valid values that you just determined. Invalid values should throw an exception.

Make sure that tests you do deals with exceptions - surround your test method in try-catch block. This applies for *all* tests you’ve written for this lab. Your `Main` class should never throw an exception - it should be handling them!

### Discuss!

Talk to someone else in the class and discuss what pre-conditions they decided for each of their fields. How do they compare to yours? Feel free to update any pre-conditions in the comments and (if any) document any potential disagreements with the people you talked to.

### Test!

You’re a good programmer, so you test what you do as you go. Check that your pre-conditions work by passing a String array with valid values and some with invalid values.

Optional: `toString()` and `equals()` methods
---------------------------------------------

If you try to print an object, Java will output the memory address of the object. However, this doesn’t tell us much and makes it difficult to see what the object is like. To make meaningful print statements, override the `toString()` method to show some of the fields. You can do this by creating a method in the class with the precise signature: `public String toString()`

Similarly, the `equals()` method, used by `assertEquals` to determine equality between objects, can be overridden for the new object you have created. Inside `Defendant.java`, fill in the method `public boolean equals(Object o)`. This method should return `true` if the objects are equal and `false` if not. You will need to cast the given object to the same type as your created task before you can check equality of the individual fields.

Finishing Your Data Storage
===========================

In the first part of this assignment you created a class to store a single row of the dataset. Now, we will create a second class to store the full dataset.

Create a new class
------------------

Create a new class that will represent the entire data set (not just one row). Think carefully about what to name it, based on your understanding of the data, so that it correctly indicates what data is being stored. Meaningful names are an essential part of good programming practice! And remember: this class should be defined in a new file, with the class name as the filename.

The `ArrayList` field
-------------------

We will store the rows of our dataset in an `ArrayList`. Make a field in your dataset class that holds an `ArrayList`, and make sure the datatype of the `ArrayList` matched what's being stored inside.

Methods
-------

### Constructor

Add a constructor that initializes the field you created as a new `ArrayList`. It should not take any parameters.

You should also write necessary getter and setter methods. Note that you might add more as necessary as you go along.

### Adding to the `ArrayList`

Recall that the data is read into an `ArrayList` of `String` arrays. We need
to iterate through the data `ArrayList`, convert each row (`String` array)
of the data `ArrayList` into the object you made in the first part of the assignment (a `Defendent`), and add
the object to the `ArrayList`.

Write a method that implements adding to the ArrayList in the class you made. You may choose to design it how you see fit.

Since exceptions may occur due to invalid or unexpected input, you will want to have a `try-catch` statement to handle them.

### Test your addition method

In your `Main` class, fill in the method called `testAdding()` to test the
method you just wrote. If you haven’t implemented `toString()` method in
the last lab, you may find it beneficial to do that now.

You can use `JUnit` as in previous tests, or print to check the list.

Reading in Data
===============

About the `OpenCSV` library
-------------------------

`OpenCSV` is a library that allows you to read in data. You can read in
data from `compas-scores.csv` using the  code below. You’ll also need
to add the appropriate imports.

We will use `CSVReaderHeaderAware` from the `OpenCSV` library for this assignment.
Because we are using a `HeaderAware` reader, it understands that the first
row is the `header` and does not include it in the data.

The following code demonstrates how you should use it to read the data
from `compas-scores.csv`:

            CSVReaderHeaderAware reader = new CSVReaderHeaderAware(
                                               new FileReader("compas-scores.csv"));
            ArrayList<String[]> myEntries = new ArrayList<String[]>(reader.readAll());
            reader.close();

This will give you an `ArrayList` (`myEntries`), where each index is a
`String` array holding the row data. The indices in the `String` array
correspond to the column indices. For example, the following is a
visualiazation `myEntries`:

    <  ["Male", "Other", "F", ...],                 // row 1
       ["Male", "African-American", "F", ...],      // row 2
       .... >

Add the data
------------

After reading in the data, use it to populate your data structure in the
class you wrote. Answer the following questions in your `README.md` file
(add a section below your name and above the questions about
difficulty/timing):

1.  If any of your validation methods indicate that your precondition
    assumptions were not met by the data, document what preconditions
    were violated and in what way. Update your validation methods one
    error at a time, documenting all issues, until you can read in all
    the data. If this did not happen, mention that.

2.  Describe a person who would generate data that would *not* pass your
    (updated) precondition assumptions.

As a last resort after updating your pre-conditions, you should make
sure you skip any rows that cause errors so that the data processing
continues. 

*Hint: if you’re having trouble with this, where could you put the `try-catch` statement so that the `try`ing happens for each row?*

Replicate the Analysis
======================

Now that you have the data read into your data structure, we can
reproduce the analysis ProPublica shows in their chart *Prediction
Fails Differently for Black Defendants.*

Write the relevant methods
--------------------------

Recall how each percentage in the table was calculated. Read
*Understanding Propublica.pdf*, and discuss with a peer or an
instructor if you need help.

In the data storage you created, write method(s) that iterate through
the `ArrayList` of `Defendants` and calculate the
percentages (in decimals). They should return the percentages as
decimals (`doubles`).

Call the methods
----------------

Call these methods in your `Main` class’s `main` method. You can check
your work by making sure your numbers match the numbers in the
ProPublica’s chart.

Your Custom Analysis
====================

What you have already done should not be altered by your work in this
section. This means you should write **additional** methods instead of
changing the methods you wrote so that your original methods stay the
same.

What counts as recidivism?
--------------------------

Find charges that, based on the `r_charge_desc`, you think should not
count as recidivism. Perform an additional analysis with these decisions
- you may need to write additional methods. Do this using an optionally
run method so that you can still run the previous version of the
analysis. Describe the choices you made and what the resulting analysis
shows in your `README.md`.
